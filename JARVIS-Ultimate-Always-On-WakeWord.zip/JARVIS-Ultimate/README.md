# JARVIS Ultimate — Android starter project

Package: `com.suraj.jarvis`  
App name: **JARVIS**  
Minimum Android: 8.0 (API 26)  
Build: Kotlin + Android Gradle Plugin, no third-party runtime libraries.

## Included

- Futuristic dark/cyan assistant screen
- Tap-to-talk speech recognition using Android's speech service
- Spoken replies using Android Text-to-Speech
- AI chat through the OpenAI Chat Completions API
- Local notes: say `remember ...`, `show memory`, or `clear memory`
- Launch installed apps: say/type `open YouTube` or `open Instagram`
- Set an alarm: say/type `set alarm 07:30` (24-hour time)
- Web search: say/type `search pharmacy jobs`

## Important limitations

1. **AI requires an API key and internet.** API usage may be billed by the provider. Create/manage your key only through the provider's official website. Never share it with anyone.
2. The API key is held in app memory only and is not written to disk. Re-enter it after restarting JARVIS.
3. Female voice depends on voices installed on Android. Set a female English voice in Android Settings → Additional settings (or Accessibility) → Text-to-speech output. Menu names vary by phone.
4. Voice input is tap-to-talk. It does not continuously listen for “Hey JARVIS”. Always-on hotword detection needs a carefully designed foreground service, battery/privacy controls, and additional testing.
5. Android deliberately restricts apps from silently changing protected system settings or controlling other apps. This project uses supported intents for app launching, web search and alarms.
6. This is a starter app. Review and test before relying on it for important reminders or actions.

## Build APK without a computer (GitHub Actions)

1. On your phone, sign in to GitHub and create a **private** repository named `jarvis-android`.
2. Upload the contents of this ZIP, preserving the folder structure. The files inside this project (including `.github/workflows/build-apk.yml`) must be at the repository root.
3. Open the repository → **Actions** → **Build JARVIS APK** → **Run workflow**.
4. Wait for the workflow to finish successfully.
5. Open the completed workflow run. Under **Artifacts**, download `JARVIS-debug-apk`.
6. Extract the ZIP artifact. It contains `app-debug.apk`.
7. Tap the APK on your phone. If Android asks, allow your browser/file manager to **Install unknown apps**, then install JARVIS.

GitHub's mobile website may show a desktop-style Actions page; use your browser menu → Desktop site if needed.

## Build with Android Studio

- Install Android Studio and Android SDK Platform 36.
- Open this project folder.
- Use JDK 17.
- Sync Gradle, then Build → Build Bundle(s) / APK(s) → Build APK(s).
- The debug APK is at `app/build/outputs/apk/debug/app-debug.apk`.

## First launch

1. Open JARVIS.
2. Tap **SETUP**, paste your API key, and leave the model as `gpt-4o-mini` unless you have a different supported model.
3. Tap **TALK** and allow microphone permission.
4. Configure a female voice in Android's Text-to-speech settings.
5. Try: `open YouTube`, `set alarm 07:30`, `remember my preferred language is English`, or ask an AI question.

## Security

- Keep the repository private if you add personal code or notes.
- Never commit API keys to GitHub or put them in source files.
- This starter app does not upload local memory notes; notes are stored in app-private preferences on the phone.


## Always-on wake-word mode (added)

This version adds a foreground microphone service using Picovoice Porcupine 4.0.2. The built-in model detects **“Jarvis”** locally. To use the exact two-word phrase **“Hey Jarvis”**, create a custom `Hey Jarvis` model in Picovoice Console, download its `.ppn` file, rename it `hey-jarvis.ppn`, and place it in `app/src/main/assets`. The service automatically uses that file when present; otherwise it falls back to the built-in single-word “Jarvis” model.

1. Create a Picovoice account at https://console.picovoice.ai/ and copy your AccessKey.
2. In JARVIS, open SETUP and enter the Picovoice AccessKey in the wake-word field.
3. Tap ENABLE HEY JARVIS while the app is visible. Grant microphone and notification permissions.
4. Keep the ongoing JARVIS notification visible. Say “Jarvis”, then speak after JARVIS says “Yes? I'm listening.”
5. Tap STOP LISTENING to stop microphone monitoring.

The wake-word engine processes audio on-device. After activation, Android's speech-recognition provider handles the spoken command; its network/offline behavior depends on the speech provider and language packs on your phone. The recognized command is sent to the app or shown in a notification to tap for the response.

### POCO / MIUI / HyperOS reliability

For best results, Settings → Apps → Manage apps → JARVIS → Battery saver → No restrictions (menu wording varies). Allow microphone and notifications. Battery saver, force-stop, reboot, privacy microphone toggle, OEM task killing, or another app taking exclusive microphone access can interrupt listening. Start the service from the visible JARVIS screen; Android 14+ restricts starting microphone foreground services from the background. A persistent notification is always shown while the service is active.

The Picovoice key is stored in the app's private preferences in this starter build. Do not share it or publish the project repository. For a production release, move credential provisioning to a secure backend or use a dedicated secret-management approach.
