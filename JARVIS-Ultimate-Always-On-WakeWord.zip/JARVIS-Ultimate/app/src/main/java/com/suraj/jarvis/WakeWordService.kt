package com.suraj.jarvis

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale

class WakeWordService : Service(), TextToSpeech.OnInitListener {
    companion object {
        const val START = "com.suraj.jarvis.START_WAKE"
        const val STOP = "com.suraj.jarvis.STOP_WAKE"
        const val COMMAND = "com.suraj.jarvis.WAKE_COMMAND"
        const val EXTRA_COMMAND = "jarvis_command"
        private const val CHANNEL = "jarvis_wake"
        private const val NOTIFY_ID = 7401
    }

    private val main = Handler(Looper.getMainLooper())
    private var detector: PorcupineManager? = null
    private var speech: SpeechRecognizer? = null
    private var voice: TextToSpeech? = null
    private var key = ""
    private var capturing = false
    private var stopped = false

    override fun onCreate() {
        super.onCreate()
        makeChannel()
        voice = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == STOP) {
            stopped = true
            stopAll()
            stopSelf()
            return START_NOT_STICKY
        }
        key = getSharedPreferences("jarvis_wake", MODE_PRIVATE).getString("pv_key", "").orEmpty()
        if (key.isBlank()) {
            stopSelf()
            return START_NOT_STICKY
        }
        stopped = false
        val notification = notification("Listening for the Jarvis wake word")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFY_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else startForeground(NOTIFY_ID, notification)
        startDetector()
        return START_STICKY
    }

    private fun makeChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL, "JARVIS always-on listening", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun notification(message: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("JARVIS is active").setContentText(message)
            .setContentIntent(open).setOngoing(true).build()
    }

    private fun update(message: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFY_ID, notification(message))
    }

    private fun startDetector() {
        if (stopped || key.isBlank()) return
        try {
            detector?.delete()
            val builder = PorcupineManager.Builder().setAccessKey(key)
            val customPhraseInstalled = assets.list("")?.contains("hey-jarvis.ppn") == true
            if (customPhraseInstalled) {
                builder.setKeywordPath("hey-jarvis.ppn")
            } else {
                builder.setKeyword(Porcupine.BuiltInKeyword.JARVIS)
            }
            detector = builder.build(this) { main.post { onWake() } }
            detector?.start()
            update("Listening for “Jarvis” • on-device detection")
        } catch (e: Exception) {
            Log.e("JARVIS", "Porcupine failed", e)
            update("Wake-word setup failed. Check the Picovoice AccessKey.")
            stopSelf()
        }
    }

    private fun onWake() {
        if (capturing || stopped) return
        capturing = true
        try { detector?.stop() } catch (_: Exception) {}
        update("Wake word heard • listening for your command")
        voice?.speak("Yes? I'm listening.", TextToSpeech.QUEUE_FLUSH, null, "jarvis_prompt")
        main.postDelayed({ listenForCommand() }, 700)
    }

    private fun listenForCommand() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            update("Speech recognition unavailable • tap to open JARVIS")
            capturing = false
            restartDetector()
            return
        }
        try {
            speech?.destroy()
            speech = SpeechRecognizer.createSpeechRecognizer(this)
            speech?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: android.os.Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: android.os.Bundle?) {}
                override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
                override fun onError(error: Int) { finishCapture("") }
                override fun onResults(results: android.os.Bundle?) {
                    val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    finishCapture(phrase)
                }
            })
            val request = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            }
            speech?.startListening(request)
        } catch (e: Exception) {
            Log.e("JARVIS", "Speech recognition error", e)
            finishCapture("")
        }
    }

    private fun finishCapture(phrase: String) {
        main.post {
            if (phrase.isNotBlank()) {
                val event = Intent(COMMAND).setPackage(packageName).putExtra(EXTRA_COMMAND, phrase)
                sendBroadcast(event)
                val open = Intent(this, MainActivity::class.java).putExtra(EXTRA_COMMAND, phrase)
                val tap = PendingIntent.getActivity(
                    this, phrase.hashCode(), open,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                val note = Notification.Builder(this, CHANNEL)
                    .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                    .setContentTitle("JARVIS heard you")
                    .setContentText(phrase.take(100) + " • tap to view response")
                    .setContentIntent(tap).setAutoCancel(true).build()
                getSystemService(NotificationManager::class.java).notify(NOTIFY_ID + 1, note)
            } else {
                update("Didn't catch that • still listening for Jarvis")
            }
            capturing = false
            restartDetector()
        }
    }

    private fun restartDetector() {
        main.postDelayed({ if (!stopped) startDetector() }, 900)
    }

    private fun stopAll() {
        main.removeCallbacksAndMessages(null)
        try { detector?.stop(); detector?.delete() } catch (_: Exception) {}
        detector = null
        try { speech?.cancel(); speech?.destroy() } catch (_: Exception) {}
        speech = null
        voice?.stop()
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else @Suppress("DEPRECATION") stopForeground(true)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) voice?.language = Locale.US
    }

    override fun onDestroy() {
        stopped = true
        stopAll()
        voice?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
